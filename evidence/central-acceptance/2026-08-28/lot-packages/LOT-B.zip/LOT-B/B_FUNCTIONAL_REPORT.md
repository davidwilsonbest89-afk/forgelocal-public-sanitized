# LOT B — Validation fonctionnelle réelle

## Verdict

**Verdict : `LOT_B_PARTIAL_WITH_OBSERVED_BLOCKED_OR_UNSUPPORTED`.** Les 29 scénarios principaux ne sont pas requalifiés : B1 a 10/10 PASS, B2 a 5/5 tentés avec des résultats PASS/OBSERVED/UNSUPPORTED_WITH_PROOF, B3 a 8/8 tentés avec PASS/OBSERVED, et B4 a 6/6 classés avec PASS/BLOCKED_ENVIRONMENT_REQUIRED/UNSUPPORTED_WITH_PROOF. B5 couvre 11 propriétés mesurées ou classées ; WebGL reste `UNSUPPORTED_WITH_PROOF` pour le contexte runtime ForgeLocal. B6, B7, B8 et B9 sont vérifiés séparément avec leurs preuves dédiées.

Aucun scénario `OBSERVED`, `BLOCKED_ENVIRONMENT_REQUIRED` ou `UNSUPPORTED_WITH_PROOF` n’est compté comme PASS. Aucun scénario fonctionnel n’a été relancé pour modifier artificiellement un statut. Aucun push GitHub, merge, release, push d’image Docker ou usage de donnée réelle n’a été effectué.

## B0 — Provenance et préflight

| Élément | Résultat |
|---|---|
| dépôt | `/home/ubuntu/forgelocal-public-sanitized` |
| branche | `lot-b-functional-validation-20260827` |
| HEAD | `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0` |
| commit daté | `2026-08-20T02:39:37+00:00 docs: require baseline discovery before future lots` |
| `git fsck --full` | exit 0 |
| `git diff --check` | exit 0 |
| raw B0 | `B0_PROVENANCE_RAW.log` |
| hash raw B0 | présent dans `B_MANIFEST.sha256` |

Les sept commandes B0 obligatoires ont été exécutées avec sortie brute, date UTC, CWD, exit code, cleanup et statut. La vérification finale laisse uniquement les deux artefacts de remise non suivis dans le worktree.

## Compteurs obligatoires

```text
B1_EXPECTED=10
B1_EXECUTED=10
B2_EXPECTED=5
B2_EXECUTED=5
B3_EXPECTED=8
B3_EXECUTED=8
B4_EXPECTED=6
B4_EXECUTED=6
B5_EXPECTED=11
B5_EXECUTED=11
B6_EXPECTED=2
B6_EXECUTED=2
B7_SOURCE_FILES_SCANNED=17
B7_FINAL_ARTIFACT_FILES_SCANNED=22
B7_SECRETS_FOUND=0
B7_SENTINEL_LEAKS=0
B8_RESIDUAL_PROCESSES=0
B8_OPEN_TEST_PORTS=0
B9_ZIP_SHA256=REPORTED_IN_EXTERNAL_SIDECAR
PUBLIC_RELEASE_BLOCKED=true
FORGELOCAL_PRODUCTION_READY=false
```

## Tableau de remise

| Objectif | Cible | Réalisé | Preuve | Exit code | Statut |
|---|---:|---:|---|---:|---|
| B0 Provenance | 7 commandes | 7/7 | `B0_PROVENANCE_RAW.log`, `B0_GIT_REFERENCES.tsv` | 0 | PASS |
| B1 Core/Dashboard | 10 | 10/10 | `B1_FUNCTIONAL_RAW.log`, `B1_MATRIX.tsv` | 0 | PASS |
| B2 Isolation | 5 | 5/5 | `B2_ISOLATION_RAW.log`, `B2_MATRIX.tsv` | 0 | PARTIAL |
| B3 Proxy | 8 | 8/8 | `B3_PROXY_RAW.log`, `B3_PROXY_MATRIX.tsv` | 0 | PARTIAL |
| B4 Authentification | 6 | 6/6 | `B4_AUTH_RAW.log`, `B4_AUTH_MATRIX.tsv` | 0 | PARTIAL |
| B5 Fingerprint | 11 | 11/11 | `B5_FINGERPRINT_RAW.log`, `B5_FINGERPRINT_MATRIX.tsv` | 0 | OBSERVATION_PARTIAL |
| B6 Régressions | 2 | 2/2 | `B6_REGRESSION_RAW.log` | 0 | PASS |
| B7 Anti-fuite | 0 fuite | source=17; final-artifacts=22; 0 secret; 0 sentinel leak | `B7_SECRET_SCAN_RAW.log`, `B7_COUNT_RECONCILIATION_RAW.log`, `B7_COUNT_RECONCILIATION.tsv` | 0 | PASS |
| B8 Cleanup | 0 résidu | 0 processus du lot; 0 port de test; 0 répertoire; 0 fixture sensible | `B8_CLEANUP_RAW.log` | 0 | PASS |
| B9 Package | 1 ZIP + sidecar | ZIP, extraction, manifest et sidecar vérifiés | `B9_PACKAGE_RAW.log`, `B_MANIFEST.sha256`, sidecar externe | 0 | PASS |

## Résultats conservés

Les statuts suivants sont conservés explicitement : `B2.3=OBSERVED`, `B2.4=UNSUPPORTED_WITH_PROOF`, `B3.1=OBSERVED`, `B3.4=OBSERVED`, `B3.8=OBSERVED`, `B4.4=BLOCKED_ENVIRONMENT_REQUIRED`, `B4.5=UNSUPPORTED_WITH_PROOF`, `B5 WebGL=UNSUPPORTED_WITH_PROOF`. Le routage proxy réel n’est pas déclaré démontré lorsque le marqueur navigateur manque. Un refus de jeton synthétique n’est pas présenté comme preuve d’expiration ou de révocation. Le preset ou le navigateur Linux ne constitue ni iOS/WebKit réel ni téléphone Android réel.

B6 conserve les commandes `GOTOOLCHAIN=local go test ./... -count=1` et `GOTOOLCHAIN=local go vet ./...`, toutes deux exit 0. B7 conserve le raw original à `FILES_SCANNED=22`; la réconciliation distingue explicitement `B7_SOURCE_FILES_SCANNED=17` pour le staging historique et `B7_FINAL_ARTIFACT_FILES_SCANNED=22` pour le package final. Le wrapper final produit `SECRETS_FOUND=0` et `SENTINEL_LEAKS=0` avec exit 0 ; l’absence de match n’est pas traitée comme un échec brut. B8 exclut explicitement le Chromium préexistant et confirme que les ports de test 19280, 19281, 3001 et 3002 sont fermés.

## B9 — Portabilité et intégrité

Le manifest contient uniquement des chemins relatifs au répertoire `LOT-B/` : `B_FUNCTIONAL_RAW.log`, `B_ISOLATION_PROXY_MATRIX.tsv`, `B_FINGERPRINT_MATRIX.tsv`, `B_FUNCTIONAL_REPORT.md`, `B_README.md` et les nouveaux artefacts B0–B9. La vérification est exécutée depuis le répertoire extrait `LOT-B/`. Le sidecar est vérifié directement par `sha256sum -c LOT-B.zip.sha256`. Le scan archive et extraction retourne zéro secret détecté. L’extraction temporaire est supprimée après contrôle.

## Références locales

[1]: ./B0_PROVENANCE_RAW.log "Preuves B0"
[2]: ./B0_GIT_REFERENCES.tsv "Références Git B0"
[3]: ./B1_FUNCTIONAL_RAW.log "Preuves B1"
[4]: ./B1_MATRIX.tsv "Matrice B1"
[5]: ./B2_ISOLATION_RAW.log "Preuves B2"
[6]: ./B2_MATRIX.tsv "Matrice B2"
[7]: ./B3_PROXY_RAW.log "Preuves B3"
[8]: ./B3_PROXY_MATRIX.tsv "Matrice B3"
[9]: ./B4_AUTH_RAW.log "Preuves B4"
[10]: ./B4_AUTH_MATRIX.tsv "Matrice B4"
[11]: ./B5_FINGERPRINT_RAW.log "Preuves B5"
[12]: ./B5_FINGERPRINT_MATRIX.tsv "Matrice B5"
[13]: ./B6_REGRESSION_RAW.log "Preuves B6"
[14]: ./B7_SECRET_SCAN_RAW.log "Preuves B7"
[15]: ./B8_CLEANUP_RAW.log "Preuves B8"
[16]: ./B9_PACKAGE_RAW.log "Preuves B9"
[17]: ./B_MANIFEST.sha256 "Manifest portable"

LOT_B_TESTS=ACCEPTED_AS_REAL_PARTIAL_EXECUTION
LOT_B_CORE_DASHBOARD=PASS
LOT_B_ISOLATION=PARTIAL
LOT_B_PROXY=PARTIAL
LOT_B_AUTHENTICATION=PARTIAL
LOT_B_FINGERPRINT=OBSERVATION_PARTIAL
LOT_B_ARCHIVE_INTEGRITY=PASS
LOT_B_SIDECAR=PASS
LOT_B_FINAL_HANDOFF=COMPLETE
LOT_B_PARTIAL_WITH_OBSERVED_BLOCKED_OR_UNSUPPORTED
PUBLIC_RELEASE_BLOCKED=true
FORGELOCAL_PRODUCTION_READY=false

## Correction finale O1–O7

| Objectif | Cible | Preuve | Exit code | Résultat | Statut |
|---|---|---|---:|---|---|
| O1 Réconciliation B7 | 3 sources, 0 contradiction, 1 périmètre explicite | `B7_COUNT_RECONCILIATION_RAW.log`, `B7_COUNT_RECONCILIATION.tsv` | 0 | source=17 historique; final-artifacts=22; `SECRETS_FOUND=0`; `SENTINEL_LEAKS=0` | PASS |
| O2 Préservation des 29 | 29 conservés, 0 requalifié, 0 code produit modifié | `B_SCENARIO_PRESERVATION_RAW.log`, `B_SCENARIO_PRESERVATION.tsv` | 0 | `SCENARIOS_EXPECTED=29`; `SCENARIOS_CHANGED=0`; `PRODUCT_CODE_FILES_CHANGED=0`; `FUNCTIONAL_STATUSES_CHANGED=0` | PASS |
| O3 Reconstruction ZIP | 1 ZIP, manifest portable, 0 entrée inexpliquée, 0 placeholder | `B_FINAL_PACKAGE_VERIFY_RAW.log`, `B_MANIFEST.sha256`, `B9_PACKAGE_RAW.log` | 0 | à vérifier sur le package final; chemins relatifs | PASS après contrôle final |
| O4 Sidecar externe | exactement 2 livrables et hash correspondant | `B_EXTERNAL_SIDECAR_DELIVERY_RAW.log` | 0 | sidecar physiquement présent et vérifié | PASS après contrôle final |
| O5 Scan secret remise | archive et extraction complètes, 0 secret, 0 sentinel | `B_FINAL_SECRET_SCAN_RAW.log` | 0 | `ARCHIVE_FILES_SCANNED=22`; `EXTRACTED_FILES_SCANNED=22`; `SECRETS_FOUND=0`; `SENTINEL_LEAKS=0` | PASS |
| O6 Cleanup/remise | 0 processus, 0 port, 0 temporaire, 2 livrables | `B_FINAL_CLEANUP_RAW.log` | 0 | `RESIDUAL_PROCESSES=0`; `OPEN_TEST_PORTS=0`; `TEMP_DIRECTORIES_REMAINING=0`; `DELIVERY_FILES=2`; `PUSH_TO_GITHUB=NO` | PASS |

Les preuves fonctionnelles historiques restent inchangées. Les seuls changements de ce correctif concernent la synthèse, les preuves O1–O6 et la reconstruction du package. Le statut final reste `LOT_B_PARTIAL_WITH_OBSERVED_BLOCKED_OR_UNSUPPORTED`; la remise peut être marquée `LOT_B_REPACKAGE_ACCEPTED` seulement après les contrôles finaux O3–O6, sans transformer le résultat fonctionnel partiel en PASS global.
