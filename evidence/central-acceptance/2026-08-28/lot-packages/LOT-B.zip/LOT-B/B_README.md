# LOT-B — Remise locale stricte

Ce répertoire contient les preuves B0–B9 du Lot B — Validation fonctionnelle réelle. Les 29 scénarios fonctionnels déjà exécutés ne sont pas relancés ni requalifiés. Le package est issu de la branche locale `lot-b-functional-validation-20260827`, HEAD `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`.

Le verdict est `LOT_B_PARTIAL_WITH_OBSERVED_BLOCKED_OR_UNSUPPORTED`. Les statuts `OBSERVED`, `BLOCKED_ENVIRONMENT_REQUIRED` et `UNSUPPORTED_WITH_PROOF` ne sont jamais comptés comme PASS. Aucun secret, compte, cookie, proxy commercial ou donnée personnelle réel n’a été utilisé. Aucun push GitHub, merge, release ou push d’image Docker n’a été effectué.

| Artefact | Rôle |
|---|---|
| `B0_PROVENANCE_RAW.log` | Sept commandes B0 avec dates, CWD, sorties, exit codes et cleanup. |
| `B0_GIT_REFERENCES.tsv` | Références dépôt, branche, HEAD, commit, fsck et diff-check. |
| `B1_FUNCTIONAL_RAW.log` | Preuves B1.1–B1.10. |
| `B1_MATRIX.tsv` | Exactement dix lignes B1 avec préconditions, commande, assertion, résultat, exit code, cleanup et statut. |
| `B2_ISOLATION_RAW.log` | Preuves B2.1–B2.5. |
| `B2_MATRIX.tsv` | Matrice des cinq contrôles d’isolation. |
| `B3_PROXY_RAW.log` | Preuves B3.1–B3.8. |
| `B3_PROXY_MATRIX.tsv` | Matrice des huit scénarios proxy. |
| `B4_AUTH_RAW.log` | Preuves B4.1–B4.6. |
| `B4_AUTH_MATRIX.tsv` | Matrice des six états d’authentification. |
| `B5_FINGERPRINT_RAW.log` | Script, navigateur/version et observations redacted des 11 propriétés. |
| `B5_FINGERPRINT_MATRIX.tsv` | Matrice des 11 propriétés fingerprint. |
| `B6_REGRESSION_RAW.log` | Deux commandes de non-régression Go et leurs exit codes. |
| `B7_SECRET_SCAN_RAW.log` | Raw B7 historique inchangé avec `FILES_SCANNED=22`, `SECRETS_FOUND=0`, `SENTINEL_LEAKS=0`. |
| `B8_CLEANUP_RAW.log` | Processus, sockets, temporaires, fixtures et diff-check. |
| `B9_PACKAGE_RAW.log` | Sidecar, ZIP, extraction, manifest, scans et entrées d’archive. |
| `B_FUNCTIONAL_RAW.log` | Journal fonctionnel complet historique conservé. |
| `B_ISOLATION_PROXY_MATRIX.tsv` | Matrice fonctionnelle historique conservée. |
| `B_FINGERPRINT_MATRIX.tsv` | Matrice fingerprint historique conservée. |
| `B_FUNCTIONAL_REPORT.md` | Rapport final et compteurs B0–B9. |
| `B_MANIFEST.sha256` | Manifest aux chemins relatifs, vérifiable depuis `LOT-B/`. |
| `B7_COUNT_RECONCILIATION_RAW.log` | Réconciliation des trois sources B7 et de leurs périmètres. |
| `B7_COUNT_RECONCILIATION.tsv` | Matrice O1 exactement trois lignes. |
| `B_SCENARIO_PRESERVATION_RAW.log` | Préservation O2 des 29 scénarios et des statuts. |
| `B_SCENARIO_PRESERVATION.tsv` | Matrice O2 des compteurs de préservation. |
| `B_FINAL_PACKAGE_VERIFY_RAW.log` | Vérification O3 du ZIP et du manifest depuis LOT-B/. |
| `B_EXTERNAL_SIDECAR_DELIVERY_RAW.log` | Vérification O4 du sidecar externe. |
| `B_FINAL_SECRET_SCAN_RAW.log` | Vérification O5 archive et extraction. |
| `B_FINAL_CLEANUP_RAW.log` | Vérification O6 du cleanup et de la remise. |
| `B_README.md` | Présent document. |

Le navigateur réellement mesuré est Chromium Linux local. Le package ne revendique ni iOS, ni Safari, ni WebKit réel, ni téléphone Android. WebGL est conservé comme non supporté dans le contexte runtime ForgeLocal ; aucune observation autonome n’est transformée en capacité produit configurable.

La réconciliation B7 distingue `B7_SOURCE_FILES_SCANNED=17` pour le staging historique et `B7_FINAL_ARTIFACT_FILES_SCANNED=22` pour la remise finale. Les commandes de remise attendues sont `sha256sum -c LOT-B.zip.sha256`, `unzip -t LOT-B.zip`, extraction fraîche, `(cd extraction/LOT-B && sha256sum -c B_MANIFEST.sha256)`, scans du ZIP et de l’extraction, puis suppression de l’extraction. Seuls `LOT-B.zip` et `LOT-B.zip.sha256` sont remis hors package.
