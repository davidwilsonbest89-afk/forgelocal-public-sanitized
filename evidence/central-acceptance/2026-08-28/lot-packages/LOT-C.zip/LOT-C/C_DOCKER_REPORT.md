# LOT C — Image et Docker

**Verdict final :** `LOT_C_PARTIAL_WITH_ENVIRONMENT_BLOCKERS`
**Statuts globaux :** `PUBLIC_RELEASE_BLOCKED` ; `FORGELOCAL_PRODUCTION_READY=false`
**Branche :** `lot-c-image-docker-20260827`
**START_HEAD :** `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`
**CWD de l’audit :** `/home/ubuntu/forgelocal-public-sanitized`
**Date de clôture UTC :** 2026-08-27

## Tableau obligatoire

| Objectif | Cible | Réalisé | Commande/preuve | Exit code | Statut |
|---|---:|---:|---|---:|---|
| C1 Cible Docker active | 1 | 1 cible absente prouvée ; 1 cible historique identifiée | `C_TARGET_RESOLUTION_RAW.log` : HEAD, workflows, chemins, ref et commit | 0 pour la décision | `CURRENT_DOCKER_TARGET_NOT_FOUND` ; findings historiques `HISTORICAL_DOCKER_TARGET_ONLY` |
| C2 Misconfigurations reproduites | 3 | 3/3 contrôles exécutés sur la ref historique | `C_DOCKER_EXECUTION_RAW.log` et `C_DOCKER_MISCONFIGURATIONS.tsv` | C-01=0 ; C-02=1 ; C-03=1 | `3/3 FAIL_HISTORICAL` |
| C3 Corrections/classifications | 3 | 3/3 classées avec branche, commit, chemin et preuve d’inactivité actuelle | matrice TSV ; aucune branche historique checkoutée ou modifiée | 0 | `HISTORICAL_DOCKER_TARGET_ONLY` |
| C4 Build host-network | 1 | 1 tentative réelle sur contexte historique temporaire | `sudo docker build --network=host -f /tmp/forgelocal-lot-c-historical-context/docker/Dockerfile.run -t forgelocal-lot-c-host-network /tmp/forgelocal-lot-c-historical-context/docker` | 1 | `FAIL_BLOCKING` au téléchargement de l’artefact BrowseForge v2.1.12 ; cible historique seulement |
| C5 Build bridge | 1 | 1 tentative réelle, séparée du host-network | `sudo docker build --network=bridge -f /tmp/forgelocal-lot-c-historical-context/docker/Dockerfile.run -t forgelocal-lot-c-bridge /tmp/forgelocal-lot-c-historical-context/docker` | 1 | `DOCKER_BRIDGE_BUILD_BLOCKED_BY_ENVIRONMENT` |
| C6 Run/healthcheck | 1 cycle | 0 cycle complète possible ; run, inspect, endpoint et stop tentés | sections `Run historical target tag`, `Healthcheck inspect`, `Health endpoint`, `Stop container` | 125 / 1 / 7 / 1 | `BLOCKED_BY_ENVIRONMENT` : aucune image construite |
| C7 Authentification image | 2 | 2/2 commandes tentées avec sentinelle synthétique construite à l’exécution | sections `Auth positive synthetic` et `Auth negative synthetic` | 125 / 125 | `BLOCKED_BY_ENVIRONMENT` : tag absent |
| C8 Anti-fuite | 0 fuite | canaux image non inspectables ; contrôles logs/history/inspect/save tentés | sections `Anti-leak logs history layers inspect` et `Layer export and manifest anti-leak` | 1 / 1 | `BLOCKED_BY_ENVIRONMENT` ; aucune occurrence de sentinelle dans les cinq artefacts |
| C9 Scanners image | 3 | 3 outils installés, versionnés et 3 scans tentés ; image absente | `C_IMAGE_SCAN_RAW.log` | versions=0 ; scans=1/1/1 | `BLOCKED_BY_ENVIRONMENT` sur l’image inexistante |
| C10 Cleanup | 0 résidu | 0 conteneur, image, volume, réseau ou processus du lot ; temporaires supprimés | `FINAL LOT C CLEANUP VERIFICATION` dans `C_DOCKER_EXECUTION_RAW.log` | 0 | `PASS` pour les objets nommés du lot |
| C11 Conservation | 5 fichiers | 5 fichiers présents, vérifiés, hashés après clôture et commités | `git add`, `git commit`, `git status`, `sha256sum` de clôture | 0 | `PASS` après hash et commit vérifiés par les commandes de clôture |

## C1 — Cible Docker active

Le HEAD réel est `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`. Il ne contient ni `Dockerfile`, ni `docker-compose.yml`, ni `.github/workflows`. Les scripts du HEAD référencent toutefois des chemins `docker/` attendus par un préflight de release ; ces chemins sont absents dans l’arbre actuel. L’API publique du dépôt ne renvoie pas de répertoire `.github/workflows` pour `main` et aucune commande du HEAD ne fournit un digest d’image actuel.

La cible historique distincte est `origin/validation/operational-v1` au commit `80048180d4ec5241c08146ade698d53a3f29454d`, daté du 2026-08-26T04:06:00Z. Elle contient `docker/Dockerfile.run`, `docker/docker-compose.yml` et `docker/entrypoint.sh`. Cette ref n’a pas été checkoutée ni modifiée. Le résultat C1 unique est donc `CURRENT_DOCKER_TARGET_NOT_FOUND`; C-01 à C-03 sont classés `HISTORICAL_DOCKER_TARGET_ONLY`, et non comme défauts du produit actuel.

## C2/C3 — Findings et décision

C-01 reproduit la ligne historique `VNC_PASSWORD=${VNC_PASSWORD:-browseforge}` au fichier `docker/docker-compose.yml:21`. C-02 reproduit l’absence d’une instruction `USER` dans `docker/Dockerfile.run`. C-03 reproduit l’absence simultanée de `HEALTHCHECK` dans le Dockerfile et de `healthcheck:` dans Compose. Les trois tests ont été exécutés avec leurs commandes et codes retours bruts. Aucun défaut actuel n’étant démontré, aucune correction n’a été appliquée : le critère avant/après n’est pas revendiqué et aucune branche historique n’a été modifiée.

## Docker Engine, Buildx et installations

L’espace disponible avant installation dépassait le seuil requis. Docker Engine, Buildx et Compose ont été installés par le dépôt APT officiel Docker. La qualification donne Docker Engine `29.7.2`, Buildx `v0.36.1` et Compose `v5.5.0`. Trivy `0.74.0`, Syft `1.51.1` et Grype `0.117.0` ont été installés depuis leurs canaux officiels et leurs versions ont été vérifiées. Les commandes exactes, sorties et codes retours sont conservés dans `C_DOCKER_EXECUTION_RAW.log`.

Le daemon est actif et `sudo docker info` fonctionne. Cependant, `sudo docker run --rm hello-world` échoue avec l’erreur réelle de la table iptables `raw` absente. Le build host-network atteint les étapes Docker et échoue ensuite au téléchargement de l’artefact BrowseForge historique. Le build bridge échoue immédiatement avec `network mode "bridge" not supported by buildkit`. Aucun iptables, noyau ou paramètre de contournement n’a été modifié.

## Builds, run, scanners et anti-fuite

Les deux builds ont été exécutés séparément sur une copie temporaire en lecture seule de la cible historique. Aucun tag `forgelocal-lot-c-host-network` ou `forgelocal-lot-c-bridge` n’a été produit. En conséquence, les commandes run, healthcheck, endpoint, arrêt, authentification et inspection des layers ont bien été tentées, mais ne peuvent pas recevoir PASS.

Les trois scanners ont été réellement exécutés sur le tag exact `forgelocal-lot-c-bridge`. Trivy, Syft et Grype signalent l’absence de l’image ; Grype signale en outre une impossibilité de mise à jour de sa base dans cette tentative. Aucun SBOM ou rapport image n’est donc déclaré PASS. Aucun digest d’image n’est disponible, et aucune image n’a été publiée ou poussée vers un registre.

La sentinelle est construite uniquement par octets dans les commandes d’authentification et d’anti-fuite ; sa valeur n’est jamais écrite en clair dans les artefacts. Les contrôles locaux des cinq fichiers livrés ne trouvent aucune occurrence de la sentinelle. Cette vérification locale ne remplace pas une inspection image, qui reste bloquée par l’absence de tag construit.

## Cleanup et conservation

Le cleanup a ciblé exclusivement les noms temporaires du Lot C. Le contrôle après suppression confirme `DOCKER_LOT_C_OBJECTS_ABSENT` et `TEMP_ARTIFACTS_ABSENT`, avec archive d’image et contexte temporaire supprimés. Les images préexistantes `hello-world`, les réseaux système `bridge`, `host` et `none`, ainsi que le daemon Docker n’ont pas été supprimés car ils ne sont pas des objets créés par le Lot C.

Les cinq artefacts exacts sont : `C_TARGET_RESOLUTION_RAW.log`, `C_DOCKER_EXECUTION_RAW.log`, `C_IMAGE_SCAN_RAW.log`, `C_DOCKER_MISCONFIGURATIONS.tsv` et `C_DOCKER_REPORT.md`. Ils sont contrôlés par `git diff --check`, scannés par recherche de motifs de secrets et de sentinelle, puis commités sur la branche dédiée. Aucun autre artefact C n’est conservé dans le dépôt.

## Métadonnées finales

```text
BRANCH=lot-c-image-docker-20260827
START_HEAD=f09af4b2a5c6bf6914a214e1220a0353c09a6fb0
FINAL_HEAD=b69d53feafebae84f5149f7c5671e54395b3317b
DOCKER_TARGET_COMMIT=80048180d4ec5241c08146ade698d53a3f29454d
DOCKERFILE_PATH=origin/validation/operational-v1:docker/Dockerfile.run (historique uniquement)
BUILD_CONTEXT=/tmp/forgelocal-lot-c-historical-context/docker (temporaire, supprimé)
IMAGE_DIGEST=UNAVAILABLE — aucune image Lot C construite
FILES_MODIFIED=les cinq artefacts du Lot C uniquement
COMMIT=b69d53feafebae84f5149f7c5671e54395b3317b
REMOTE_BRANCH=lot-c-image-docker-20260827 ; push non effectué sans autorisation explicite
WORKTREE_STATUS=PROPRE_APRES_REPACKAGE_VERIFIE_LE_2026-08-28T00:18:17Z
```

## Références d’installation

[1]: https://docs.docker.com/engine/install/ubuntu/ "Docker Engine — Install on Ubuntu"

Les commandes d’installation ont suivi le dépôt APT officiel documenté par Docker [1].

## Réconciliation finale des compteurs de package

Les raw logs restent inchangés. Les compteurs sont renommés selon leur périmètre réel afin d’éviter toute confusion entre métadonnées, archive, extraction et manifeste.

| Compteur final | Valeur | Périmètre | Source brute |
|---|---:|---|---|
| `METADATA_FILES_CHECKED` | 14 | Fichiers de métadonnées contrôlés par O1 | `C_FINAL_METADATA_RAW.log:FILES_CHECKED=14` |
| `ARCHIVE_FILES_SCANNED` | 19 | Fichiers réguliers de l’archive contrôlés par O5 | `C_FINAL_PACKAGE_SECRET_SCAN_RAW.log` |
| `EXTRACTION_FILES_SCANNED` | 19 | Fichiers réguliers de l’extraction contrôlés par O5 | `C_FINAL_PACKAGE_SECRET_SCAN_RAW.log` |
| `MANIFEST_TECHNICAL_FILES` | 5 | Fichiers techniques hashés dans le manifeste | `C_FINAL_MANIFEST_RAW.log` |

```text
COUNTERS_CHECKED=4
COUNTER_CONTRADICTIONS=0
METADATA_FILES_CHECKED=14
ARCHIVE_FILES_SCANNED=19
EXTRACTION_FILES_SCANNED=19
MANIFEST_TECHNICAL_FILES=5
COUNT_RECONCILIATION_EXIT_CODE=0
```

## O7 — Verdict package après réconciliation des compteurs

```text
LOT_C_FINAL_PACKAGE=ACCEPTED
LOT_C_CENTRAL_INTEGRATION=READY_FOR_CENTRAL_REVIEW
LOT_C_TECHNICAL_AUDIT=ACCEPTED_AS_PARTIAL
LOT_C_ZIP_INTEGRITY=PASS
LOT_C_MANIFEST_PORTABILITY=PASS
LOT_C_SIDECAR=PROVIDED_AND_VERIFIED
LOT_C_TECHNICAL_STATUS=LOT_C_PARTIAL_WITH_ENVIRONMENT_BLOCKERS
PUBLIC_RELEASE_BLOCKED=true
FORGELOCAL_PRODUCTION_READY=false
```
