# LOT D — Provenance, CI et environnements

## Décision

**Verdict de lignée : `HISTORICAL_EVIDENCE_UNVERIFIED`**.

**Verdict global : `LOT_D_PARTIAL_WITH_ENVIRONMENT_BLOCKERS`**.

Le HEAD du Lot D `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0` est synchronisé avec `origin/main`, mais il n’a aucun merge-base avec le HEAD R7 fourni `9aba6ed109c54539b1e2fd8b083ec2c5c7e727e3`, et aucun des deux n’est ancêtre de l’autre. Le commit T08 `99a22f5106ebf0cef27e46c551757de8355e5cad` est présent comme objet Git, mais son merge-base avec le HEAD D est vide et il n’est pas ancêtre du HEAD D. Ces relations locales négatives ne suffisent toutefois pas à établir une lignée complète entre les dépôts nommés.

Les dépôts historiques `boucheriechefimane-cmd/IPcache` et `forgelocal-product-v0.3` n’ont pas pu être lus par API ou Git sans identifiants. Conformément à la règle du mandat, un dépôt inaccessible reste **UNVERIFIED**; le verdict D2 est donc `HISTORICAL_EVIDENCE_UNVERIFIED`. Aucun PASS T07/T08 n’est transféré.


Les statuts globaux restent inchangés : **`PUBLIC_RELEASE_BLOCKED`**, **`FORGELOCAL_PRODUCTION_READY=false`**, **`INDEPENDENT_REVIEW_PENDING`**.

## Tableau obligatoire D1–D14

| Objectif | Cible | Réalisé | Commande/preuve | Exit code | Statut |
|---|---:|---:|---|---:|---|
| D1 HEAD local/distant | 1 | `LOCAL_HEAD=REMOTE_HEAD=f09af4b2a5c6bf6914a214e1220a0353c09a6fb0` | `GIT_TERMINAL_PROMPT=0 git ls-remote origin HEAD refs/heads/main; git rev-parse HEAD` | 0 | **PASS** |
| D2 Verdict lignée T07/T08 | 1 | Objet T08 présent mais relations locales négatives; dépôts historiques externes inaccessibles; la lignée complète ne peut pas être démontrée | `git cat-file -t T08; git merge-base T08 HEAD; git merge-base --is-ancestor T08 HEAD; API/Git des dépôts historiques` | collecteur 0; relations négatives exit 1; sources externes 404/auth | **HISTORICAL_EVIDENCE_UNVERIFIED** |
| D3 Références T08 | 6 | `6/6` présents: `31a51e9`, `99a22f5`, `0e6a95f`, `e10a48c`, `903f6bd`, `f3a19df`; type, parent, date, sujet et relation consignés | `git cat-file -t`; `git show -s --format`; `git merge-base --is-ancestor` pour chaque référence | 0 collecteur; relations vers HEAD exit 1 | **PASS_COVERAGE_WITHOUT_LINEAGE_TRANSFER** |
| D4 Chemins T08 comparés | 2 | `internal/launch/` présent dans T08 et HEAD avec hashes/diff; `docs/component-rights-register.json` présent dans T08 et absent dans HEAD | `git ls-tree -r T08/HEAD -- internal/launch docs/component-rights-register.json`; `git diff --stat T08 HEAD -- chemins` | 0 | **PASS_COMPARISON** |
| D5 CI HEAD courant | 1 | `check-runs` HEAD `total_count=0`; Actions `head_sha` `total_count=0`; `main` `total_count=0`; workflow CI actif id `343413435`, aucun run | API GitHub check-runs, workflow runs, liste des workflows | 0 API; `total_count=0` | **NO_RUN_FOUND** |
| D6 Protection branche | 1 | API `main` HTTP 401 `Requires authentication` | `curl -sS -D - https://api.github.com/repos/davidwilsonbest89-afk/forgelocal-public-sanitized/branches/main/protection` | 0 curl; HTTP 401 | **BRANCH_PROTECTION_NOT_VERIFIED** |
| D7 Chromium binaire | 1 | Chromium `151.0.7922.71`; HTML attendu retourné | `command -v chromium`; `chromium --version`; smoke `--headless --dump-dom` | 0 | **PASS** |
| D8 Chromium ForgeLocal | 1 | Le chemin natif est identifié mais non lancé: il requiert un service loopback et un token synthétique; aucun token n’a été utilisé | `./scripts/browseforge-native-smoke.sh` non exécuté | NOT_EXECUTED | **BLOCKED_ENVIRONMENT_REQUIRED** |
| D9 Firefox | 1 | Binaire absent; aucune installation | `command -v firefox`; `firefox --headless --version` | 127 | **FIREFOX_NOT_EXECUTED_ENVIRONMENT_UNAVAILABLE** |
| D10 Camoufox | 1 | Binaire absent; aucune installation ou téléchargement | `command -v camoufox`; `camoufox --version` | 127 | **CAMOUFOX_NOT_EXECUTED_ENVIRONMENT_UNAVAILABLE** |
| D11 SystemVault natif | 1 | Gate refusé dans le conteneur; `MemoryVault` exclu | `./scripts/run-systemvault-native-gate.sh` | 3 | **BLOCKED_ENVIRONMENT_REQUIRED** |
| D12 Go/T08 | 3 | Go `1.25.13` disponible; race initial exit 2 (`CGO` requis), retry CGO exit 1 (`gcc` absent); vet exit 0; build exit 0 | `go version`; `go test -count=1 -race ./internal/launch`; retry `CGO_ENABLED=1`; `go vet ./internal/launch`; `go build ./internal/launch` | 0/2/1/0/0 | **PARTIAL_WITH_RACE_BLOCKER** |
| D13 Nettoyage | 0 résidu | Aucun répertoire temporaire du lot; `git diff --check` exit 0; les processus Chromium observés sont préexistants dans la sandbox et ne sont pas des processus Firefox/Camoufox/lot D | `find /tmp ...`; `git status --short --branch`; `git diff --check`; `pgrep -af 'chromium|firefox|camoufox|forgelocal' || true` | 0 | **PASS_WITH_PREEXISTING_CHROMIUM** |
| D14 Conservation | 4 fichiers | Les quatre fichiers sont présents; la remise locale reprend le HEAD réel 607d78e; aucun commit/push supplémentaire n’est créé | `git rev-parse HEAD`; `git status --short --branch`; `git push` non exécuté | 0 pour D0; non exécuté pour push | **READY_FOR_LOCAL_REPACKAGE** |

## Identifiants du lot

```text
BRANCH=lot-d-provenance-environments-20260827
START_HEAD=f09af4b2a5c6bf6914a214e1220a0353c09a6fb0
ARTIFACT_COMMIT=817b31ce9765747b33e493d4fd712a5a0a9ede56
FINAL_HEAD=607d78e51fce9a72ddab48c6c7b65b9e4df533a8
FINAL_COMMIT=NOT_USED
LOCAL_COMMIT=607d78e51fce9a72ddab48c6c7b65b9e4df533a8
PUSH_TO_GITHUB=NO
FILES_MODIFIED=D_PROVENANCE_RAW.log D_CI_RAW.log D_ENVIRONMENT_MATRIX.tsv D_ENVIRONMENT_REPORT.md
COMMIT=607d78e51fce9a72ddab48c6c7b65b9e4df533a8
REMOTE_BRANCH=NOT_USED_PUSHTOGITHUB_NO
WORKTREE_STATUS=MODIFIED_PROOF_REPACKAGE
```

Une tentative de push historique, antérieure à cette remise locale, est conservée dans `D_CI_RAW.log` et a retourné exit code 128 (`could not read Username`). Pour cette remise, `PUSH_TO_GITHUB=NO` et aucune commande push n’est exécutée.

Le scan externe final a retourné quatre lignes `CLEAN`; les SHA-256 de l’état commité sont recalculés après ce commit et restitués séparément pour éviter une auto-référence du hash de ce rapport.

Les preuves brutes, avec commande exacte, date UTC, CWD, sortie brute et exit code, sont dans [`D_PROVENANCE_RAW.log`](./D_PROVENANCE_RAW.log) et [`D_CI_RAW.log`](./D_CI_RAW.log). La matrice structurée est [`D_ENVIRONMENT_MATRIX.tsv`](./D_ENVIRONMENT_MATRIX.tsv).

## Limites et interdictions maintenues

Aucun code produit, Dockerfile, Compose, registre de droits, T28, T29 ou T31–T38 n’a été modifié. Aucune branche `main` ou historique n’a été modifiée. Aucun proxy réel, compte réel, cookie réel ou secret réel n’a été utilisé. Aucun PASS historique T07/T08 n’a été transféré au HEAD actuel. Aucune release n’a été publiée et aucune image Docker n’a été poussée.

Le smoke Chromium est uniquement une preuve du binaire système; il ne constitue pas la qualification native ForgeLocal D8. Firefox et Camoufox restent non exécutés faute de binaire. SystemVault natif reste bloqué par le contexte conteneurisé. Le test race Go a été réellement tenté, puis retenté avec Cgo activé; l’absence de GCC empêche sa réussite. `go vet` et `go build` ont, eux, terminé avec exit code 0.

## Références

[1]: https://github.com/davidwilsonbest89-afk/forgelocal-public-sanitized "Dépôt public ForgeLocal sanitized"
[2]: https://api.github.com/repos/davidwilsonbest89-afk/forgelocal-public-sanitized/actions/runs "API GitHub Actions runs"
[3]: https://api.github.com/repos/davidwilsonbest89-afk/forgelocal-public-sanitized/branches/main/protection "API GitHub branch protection"
[4]: https://api.github.com/repos/davidwilsonbest89-afk/forgelocal-public-sanitized/actions/workflows "API GitHub workflows"

## Repackage D0–D7

Cette section documente uniquement la correction de remise, sans refaire D2–D13. D0 est **PASS** avec `git rev-parse HEAD=607d78e51fce9a72ddab48c6c7b65b9e4df533a8`; `FINAL_HEAD` et `LOCAL_COMMIT` reprennent cette valeur, `FINAL_COMMIT=NOT_USED`, et `PUSH_TO_GITHUB=NO`. D1 est **PASS** : les champs finaux sont cohérents dans les cinq fichiers analysés et dans `D_README.md`.

Le statut hérité D2 reste `HISTORICAL_EVIDENCE_UNVERIFIED`; D3 à D13 conservent leurs résultats précédents sans modification abusive. Pour le scan package, Gitleaks n’est pas disponible : `gitleaks version` a retourné exit code 127 et le statut est `NOT_EXECUTED_ENVIRONMENT_UNAVAILABLE`. La classification séparée est `REAL_SECRET_MATCHES=0` et `SCANNER_PATTERN_SELF_MATCHES=1`; la seule auto-correspondance provient d’une commande regex documentaire conservée dans le raw log et ne constitue pas un secret. Le scan indépendant du payload, qui exclut explicitement les lignes `COMMAND=`, a retourné exit code 0; il ne remplace pas Gitleaks.

D4 est **PASS** : le manifeste contient exactement les hashes de `D_PROVENANCE_RAW.log`, `D_CI_RAW.log`, `D_ENVIRONMENT_MATRIX.tsv`, `D_ENVIRONMENT_REPORT.md` et `D_README.md`, sans auto-référence ni référence au ZIP. Aucune assignation interne du hash ZIP n’est conservée; la source du hash ZIP est exclusivement le sidecar externe (`ZIP_HASH_SOURCE=EXTERNAL_SIDECAR`, `ZIP_HASH_NOT_EMBEDDED_TO_AVOID_CIRCULARITY=true`). D5 et D6 sont **PASS** pour `unzip -t`, extraction fraîche et `sha256sum -c`. Le sidecar externe est présent et sa vérification retourne exit code 0. D7 est **PASS** pour la remise locale des deux fichiers `LOT-D.zip` et `LOT-D.zip.sha256`; aucun push GitHub n’est exécuté.
