# LOT-D — Repackage local unique

```text
LOT=D
BRANCH=lot-d-provenance-environments-20260827
START_HEAD=f09af4b2a5c6bf6914a214e1220a0353c09a6fb0
ARTIFACT_COMMIT=817b31ce9765747b33e493d4fd712a5a0a9ede56
FINAL_HEAD=607d78e51fce9a72ddab48c6c7b65b9e4df533a8
FINAL_COMMIT=NOT_USED
LOCAL_COMMIT=607d78e51fce9a72ddab48c6c7b65b9e4df533a8
PUSH_TO_GITHUB=NO
WORKTREE_STATUS=MODIFIED_PROOF_REPACKAGE
D2=HISTORICAL_EVIDENCE_UNVERIFIED
D3_SECRET_SCAN=NOT_EXECUTED_ENVIRONMENT_UNAVAILABLE
REAL_SECRET_MATCHES=0
SCANNER_PATTERN_SELF_MATCHES=1
D4_MANIFEST=PASS
D5_ZIP=PASS
D6_EXTRACTION=PASS
D7_LOCAL_HANDOFF=PASS
ZIP_HASH_SOURCE=EXTERNAL_SIDECAR
ZIP_HASH_NOT_EMBEDDED_TO_AVOID_CIRCULARITY=true
GLOBAL_VERDICT=LOT_D_PARTIAL_WITH_ENVIRONMENT_BLOCKERS
PUBLIC_RELEASE_BLOCKED=true
FORGELOCAL_PRODUCTION_READY=false
INDEPENDENT_REVIEW_PENDING=true
```

`FINAL_HEAD` et `LOCAL_COMMIT` sont la valeur réelle du HEAD observé par D0. `ARTIFACT_COMMIT` est conservé uniquement comme commit historique qui a ajouté les preuves. `FINAL_COMMIT=NOT_USED` signifie qu’aucun nouveau commit n’a été créé pour ce repackage. Aucun push GitHub n’est exécuté.

Gitleaks est indisponible dans l’environnement et conserve l’exit code 127. Le scan indépendant du payload est propre avec `REAL_SECRET_MATCHES=0`; `SCANNER_PATTERN_SELF_MATCHES=1` désigne seulement une commande regex documentaire conservée dans un raw log.

Le hash du ZIP n’est pas embarqué afin d’éviter la circularité. Il est fourni exclusivement dans `LOT-D.zip.sha256`. Le manifeste couvre exactement les cinq fichiers non-manifest de ce répertoire et ne contient ni son propre hash ni le hash du ZIP.
