# LOT-A — preuves de triage et correction sécurité

Ce paquet contient les preuves locales du Lot A exécuté sur le dépôt `davidwilsonbest89-afk/forgelocal-public-sanitized`. Le travail a été réalisé sur la branche locale `lot-a-security-20260827`, sans push GitHub, sans release, sans image Docker et sans traitement du périmètre Docker/image.

Le `START_HEAD` est `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`. Le commit local de livraison est `51b33cb039a57e8b6390cca67c0e0087c67c0f78`. Le worktree du dépôt est propre et `main` demeure sur `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`.

Le paquet conserve les sorties JSON, les matrices Grype historique et courante, les matrices Semgrep custom/no-git-ignore/auto, le journal brut avec commandes, dates UTC, CWD, sorties et exit codes, le diff de sécurité et le rapport. Le manifeste `A_MANIFEST.sha256` ne s’auto-référence pas : il couvre tous les fichiers du répertoire `LOT-A/` sauf lui-même.

Le verdict est `LOT_A_PARTIAL_WITH_OPEN_FINDINGS`. Les compteurs établis sont : Grype historique 46/46, dont 24 High/Critical ; Grype courant 140/140, dont 50 High/Critical ; Semgrep custom 18/18 ; Semgrep custom `--no-git-ignore` 18/18 ; Semgrep auto 13/13. L’objectif historique Semgrep à 46 reste `BLOCKED_NOT_ESTABLISHED`, sans lignes inventées. Aucun patch de code produit n’a été annoncé : `PRODUCT_CODE_PATCHES=0`, les findings non résolus restent ouverts.

Le paquet ne contient aucun secret réel, token, cookie, compte, proxy commercial ou donnée utilisateur. Le scan Gitleaks final sur l’ensemble du contenu remis a retourné `[]` avec exit code 0.

## Métadonnées de remise

```text
START_HEAD=f09af4b2a5c6bf6914a214e1220a0353c09a6fb0
ARTIFACT_COMMIT=NOT_USED
FINAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
LOCAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
PUSH_TO_GITHUB=NO
``` 

Le commit est unique pour les artefacts du Lot A ; il n’existe donc pas de commit d’artefact distinct.

FINAL_HEAD=51b33cb039a57e8b6390cca67c0e0087c67c0f78
FINAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
LOCAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
ARTIFACT_COMMIT=NOT_USED

## Preuves O1–O6

```text
O1 SIDECAR=PASS
O2 METADATA=PASS
O3 SECURITY_PRESERVATION=PASS
O4 PACKAGE_VERIFY=PASS
O5 SECRET_SCAN=PASS_BASED_ON_PRIOR_VERIFIED_EXECUTION
O6 CLEANUP=PASS
```

Le mandat de correction finale interdit de relancer Grype, Semgrep, Gitleaks et les tests produit. Le résultat Gitleaks conservé dans `A_PACKAGE_SECRET_SCAN_FINAL_RAW.log` est donc la dernière exécution réelle déjà vérifiée dans le périmètre du package précédent ; aucune nouvelle exécution n’est présentée comme ayant eu lieu pour cette correction administrative.
