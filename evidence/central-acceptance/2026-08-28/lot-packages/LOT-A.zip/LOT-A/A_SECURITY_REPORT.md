# ForgeLocal — Lot A — Triage et correction sécurité

**Verdict : `LOT_A_PARTIAL_WITH_OPEN_FINDINGS`**. Les outils disponibles ont été exécutés sur le clone neuf, les compteurs établis sont conservés sans réduction artificielle du périmètre, et aucun patch produit n’a été forcé lorsqu’aucun défaut corrigeable n’était démontré. Les findings non résolus restent ouverts. L’objectif historique Semgrep à 46 est `BLOCKED_NOT_ESTABLISHED`, car les JSON et refs autoritatives retrouvés établissent 18 findings custom, pas 46.

## Tableau obligatoire

| Objectif | Cible | Réalisé | Preuve | Exit code | Statut |
|---|---:|---:|---|---:|---|
| A1 Grype historique | 46 | 46/46 lignes, 46/46 rattachées, 46/46 uniques selon `vulnerability_id+component+installed_version+artifact_path` | `A_GRYPE_FINDINGS.tsv`, JSON `8e26bfb:V6_GRYPE_CYCLONEDX.json`, SHA-256 `81bc604207fa7f8ceec2033b388f9652daf0355b9d86a7c68d4047865b43c9a0` | 0 | PASS limité au comptage |
| A2 Grype historique H/C | 24 | 24/24 décisions individuelles | `A_GRYPE_FINDINGS.tsv` : 24 `OPEN_MANUAL_REVIEW_REQUIRED` | 0 | PASS limité au triage |
| A3 Grype courant | 140 | 140/140 matches comptés depuis le JSON courant | `A_GRYPE_SOURCE_AFTER.json`, `A_GRYPE_FINDINGS.tsv` | 0 | PASS |
| A4 Grype courant H/C | 50 | 50/50 identifiés et classés | `A_GRYPE_FINDINGS.tsv` : 50 `OPEN_MANUAL_REVIEW_REQUIRED` | 0 | PASS limité au classement |
| A5 Semgrep custom | 18 | 18/18 rattachés à règle, fichier, ligne, code et chemin d’appel | `A_SEMGREP_FINDINGS.tsv`, `A_SEMGREP_CUSTOM_AFTER.json` | 0 | PASS |
| A6 Semgrep no-git-ignore | 18 comparés | 18/18 comparés aux 18 standards, mêmes règles/emplacements | `A_SEMGREP_FINDINGS.tsv`, `A_SEMGREP_CUSTOM_NOIGNORE_AFTER.json` | 0 | PASS |
| A7 Semgrep auto | 13 | 13/13 rattachés séparément | `A_SEMGREP_FINDINGS.tsv`, `A_SEMGREP_AUTO_AFTER.json` | 0 | PASS limité au scan auto |
| A8 Semgrep historique | 46 ou BLOCKED | 46 non établis ; 18 custom historiques établis | JSON/refs historiques consultés ; aucune ligne fictive ajoutée | 0 | BLOCKED_NOT_ESTABLISHED |
| A9 Corrections | 100 % prouvées | 0 patch produit ; donc 0 correction annoncée | `A_SECURITY_DIFF.patch`, `git diff --check` | 0 | NOT_APPLICABLE |
| A10 Rescans | 100 % des corrections | 0 correction à resscanner ; scanners rejoués pour qualification | `A_SECURITY_RAW.log` | 0 | NOT_APPLICABLE |
| A11 Secrets | 0 | 0 leak Gitleaks sur les six livrables nouveaux | Gitleaks 8.18.4 `detect --no-git`, rapport JSON vide de 3 octets | 0 | PASS |
| A12 Livrables | 4 | 4 minimum présents, non vides, hashés et vérifiés ; matrices et JSONs supplémentaires conservés | `A_SECURITY_RAW.log`, hashes et contrôle final | 0 | PASS |

## Résultats et compteurs

Le HEAD réel découvert avant modification est `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0`, sur la branche dédiée `lot-a-security-20260827`. `main` et `origin/main` restent sur ce même HEAD. Aucun fichier de code produit n’a été modifié. Aucun secret réel, cookie réel, compte réel, proxy commercial, release ou push Docker n’a été utilisé.

Le JSON Grype historique réel contient 46 matches : **1 Critical, 23 High, 20 Medium et 2 Low**, soit 24 High/Critical. Les 24 lignes historiques High/Critical restent ouvertes pour revue manuelle, car elles proviennent d’un binaire `@esbuild/linux-x64` situé sous `node_modules`, artefact absent de l’arbre courant. Les 22 lignes historiques Medium/Low sont `NOT_APPLICABLE_WITH_PROOF` pour le clone courant, avec chemin historique et absence vérifiée.

Le rescan Grype du HEAD courant avec Grype 0.117.0 retourne **140 matches : 2 Critical, 48 High, 79 Medium, 9 Low et 2 Unknown**, soit **50 High/Critical**. Les 140 lignes sont présentes dans `A_GRYPE_FINDINGS.tsv`; les 50 High/Critical sont toutes classées `OPEN_MANUAL_REVIEW_REQUIRED`. Aucun finding courant n’est présenté comme corrigé, non applicable ou exception approuvée sans preuve individuelle.

Les matrices Semgrep séparées établissent **18 custom avec Git ignore**, **18 custom avec `--no-git-ignore`**, et **13 auto**. Les deux exécutions custom ont les mêmes 18 règles et emplacements. Le compteur historique 46 Semgrep est bloqué et n’est pas complété artificiellement. Le champ `code_exact` des matrices est extrait des fichiers du HEAD à partir des lignes `start.line`/`end.line` du JSON, afin de ne pas recopier le placeholder de contexte éventuellement renvoyé par Semgrep.

## Corrections et tests

Aucun défaut n’a satisfait le protocole complet « reproduction avant avec échec, diff minimal, test de régression, tests du package, vet/build, rescan et comparaison ». En conséquence, `PRODUCT_CODE_PATCHES=0`, `FINDINGS_REMAIN_OPEN_WITH_TECHNICAL_REASON`, et aucun finding n’est marqué `FIXED_AND_RETESTED` ou `TEMPORARY_EXCEPTION_APPROVED`. Le patch produit est vide par conception et est décrit dans `A_SECURITY_DIFF.patch`.

Les tests applicables ont été exécutés sans modification de code : `timeout 300s go test -count=1 ./...` exit 0, `timeout 300s go vet ./...` exit 0, `timeout 300s go build ./...` exit 0, puis `CGO_ENABLED=1 timeout 300s go test -count=1 -race ./cmd/... ./internal/...` exit 0 à 2026-08-27T18:53:31Z. Les deux tentatives précédentes du test race ont été conservées comme échecs d’environnement : CGO désactivé exit 2, puis compilateur gcc absent exit 1 ; après installation locale du compilateur open source, le même test a réussi. Comme aucune correction n’a été annoncée, aucun test ciblé post-correction n’est déclaré artificiellement. `git diff --check` exit 0.

## Contrôle des secrets et cleanup

Gitleaks 8.18.4 a scanné les six livrables nouveaux dans un répertoire isolé avec `detect --no-git --source /tmp/lotA-new --redact --no-banner --report-format json --report-path /tmp/lotA-gitleaks-no-git.json`; la sortie est `no leaks found`, le rapport JSON contient `[]` et l’exit code est 0 à 2026-08-27T18:51:39Z. La première commande tentée avec la sous-commande inexistante `dir` a échoué exit 1 et n’est pas utilisée comme preuve. Le contrôle est conservé dans `A_SECURITY_RAW.log`. Aucun token ni sentinelle n’est affiché dans les matrices ou le rapport ; les sorties JSON brutes de Semgrep restent attachées comme preuves scanner et ne sont pas utilisées comme code exact.

Le cleanup final a été vérifié avec exit code 0 : aucune modification suivie, aucun processus Go de test/vet/build actif, absence du binaire historique `node_modules`, aucun répertoire Docker local, et `main`/`origin/main` inchangées. Docker est indisponible (`docker: command not found`, exit 127) ; les **43 findings Grype image** annoncés par le périmètre utilisateur sont donc comptés séparément, non traités dans le Lot A et restent `OPEN/BLOCKED`.

## Identifiants obligatoires

| Champ | Valeur |
|---|---|
| `START_HEAD` | `f09af4b2a5c6bf6914a214e1220a0353c09a6fb0` |
| `FINAL_HEAD` | `51b33cb039a57e8b6390cca67c0e0087c67c0f78` |
| `BRANCH` | `lot-a-security-20260827` |
| `FILES_MODIFIED` | `A_SECURITY_RAW.log`, `A_GRYPE_FINDINGS.tsv`, `A_SEMGREP_FINDINGS.tsv`, `A_SECURITY_FINDINGS.tsv`, `A_SECURITY_DIFF.patch`, `A_SECURITY_REPORT.md`, JSONs de scan |
| `COMMIT` | `51b33cb039a57e8b6390cca67c0e0087c67c0f78` |
| `GRYPE_JSON_SHA256` | `84aa3872806c187f5d7ce5af661f196f333a5bde155c545121c94047083ef23e` |
| `SEMGREP_CUSTOM_JSON_SHA256` | `957396351406cb4b607f70a892ee2f8a582d4aed5eee4ed7649c424ef3314e8e` |
| `SEMGREP_NOIGNORE_JSON_SHA256` | `e1f8c323669d11c65d861c2357c52ab22041883d44c0ab92bd620f6ed05bf92c` |
| `SEMGREP_AUTO_JSON_SHA256` | `42cf387d7856a12f2045b20b69a1cd046b1bf190c0263a5f03b86a8c769adc88` |
| `WORKTREE_STATUS` | `CLEAN after final commit (verified after amend)` |
| `A_SECURITY_RAW_SHA256` | `3f9df293bdb27f08c445ac1ae4b37506ed6404d3d5806ecc809f3fadd9784c16` |
| `A_GRYPE_FINDINGS_SHA256` | `cd4140f61bc6cb0bfdb8306f927a9642fc5e82cef0d55532728783ed0f3e367f` |
| `A_SEMGREP_FINDINGS_SHA256` | `160056bdef6b39dc9d4dbd5bd0181d26bde555ac3491595fe5a250926fcd462c` |
| `A_SECURITY_FINDINGS_SHA256` | `d6daa57238b50c1d33af2ede9b02e5a76be3878d4e773f1a47b11fe629ded2eb` |
| `A_SECURITY_DIFF_SHA256` | `6d4d1a8eaf756c46ca522c9ba47da354c00f1f563eb8acdd664ef1d83567e778` |
| `A_SECURITY_REPORT_SHA256` | `see A_SECURITY_HASHES.sha256` |

## Références de cadrage

[1]: https://github.com/anchore/grype "Anchore Grype"
[2]: https://semgrep.dev/docs/ "Semgrep Documentation"
[3]: https://github.com/gitleaks/gitleaks "Gitleaks"
[4]: https://go.dev/doc/ "Go Documentation"

## Métadonnées finales de remise

```text
FINAL_HEAD=51b33cb039a57e8b6390cca67c0e0087c67c0f78
FINAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
LOCAL_COMMIT=51b33cb039a57e8b6390cca67c0e0087c67c0f78
ARTIFACT_COMMIT=NOT_USED
```

La cohérence de ces champs est prouvée dans `A_METADATA_FINAL_RAW.log` et `A_METADATA_FINAL_MATRIX.tsv`. Les résultats de sécurité restent inchangés : `PRODUCT_CODE_PATCHES=0`, Grype historique `46` dont `24` High/Critical, Grype courant `140` dont `50` High/Critical, Semgrep custom `18`, Semgrep custom no-git-ignore `18`, Semgrep auto `13`, et Semgrep historique `BLOCKED_NOT_ESTABLISHED`.

`LOT_A_REPACKAGE=ACCEPTED`, `LOT_A_PROVENANCE=ACCEPTED`, `LOT_A_MANIFEST=PASS`, `LOT_A_ARCHIVE_INTEGRITY=PASS`, `LOT_A_SIDECAR=PROVIDED_AND_VERIFIED`, `LOT_A_CENTRAL_INTEGRATION=READY_FOR_CENTRAL_REVIEW`, `PUBLIC_RELEASE_BLOCKED=true`, `FORGELOCAL_PRODUCTION_READY=false`, `INDEPENDENT_REVIEW_PENDING=true`.

## Correction finale de remise — O1 à O6

| Objectif | Preuve | Exit code | Statut |
|---|---|---:|---|
| O1 Sidecar externe | `A_SIDECAR_FINAL_RAW.log`, `LOT-A.zip.sha256` contenant `867065de01ddc62d4dec7b034d2176e7f562356856cc5b68cc06d61105ed59e3  LOT-A.zip` | 0 | PASS |
| O2 Métadonnées | `A_METADATA_FINAL_RAW.log`, `A_METADATA_FINAL_MATRIX.tsv`, 3 fichiers contrôlés, 12 lignes | 0 | PASS |
| O3 Préservation sécurité | `A_SECURITY_PRESERVATION_RAW.log`, `A_SECURITY_COMPARISON.tsv` | 0 | PASS |
| O4 Package | `A_PACKAGE_FINAL_VERIFY_RAW.log` | 0 | PASS |
| O5 Secrets | `A_PACKAGE_SECRET_SCAN_FINAL_RAW.log` et rapports JSON conservés | 0 observé lors de la dernière exécution autorisée | PASS dans le périmètre annoncé |
| O6 Cleanup/remise | `A_FINAL_CLEANUP_RAW.log` | 0 | PASS |

Le périmètre de cette correction est administratif. Conformément au mandat, aucun scan Grype/Semgrep/Gitleaks, test Go ou test produit n’a été relancé. Les résultats restent inchangés : `PRODUCT_CODE_PATCHES=0`, Grype historique `46` dont `24` High/Critical, Grype courant `140` dont `50` High/Critical, Semgrep custom `18`, Semgrep custom no-git-ignore `18`, Semgrep auto `13`, Semgrep historique `BLOCKED_NOT_ESTABLISHED`, `FINDINGS_CLOSED=0`, `NEW_EXCEPTIONS=0`.

`LOT_A_REPACKAGE=ACCEPTED`, `LOT_A_PROVENANCE=ACCEPTED`, `LOT_A_MANIFEST=PASS`, `LOT_A_ARCHIVE_INTEGRITY=PASS`, `LOT_A_SIDECAR=PROVIDED_AND_VERIFIED`, `LOT_A_CENTRAL_INTEGRATION=READY_FOR_CENTRAL_REVIEW`, `PUBLIC_RELEASE_BLOCKED=true`, `FORGELOCAL_PRODUCTION_READY=false`, `INDEPENDENT_REVIEW_PENDING=true`.
