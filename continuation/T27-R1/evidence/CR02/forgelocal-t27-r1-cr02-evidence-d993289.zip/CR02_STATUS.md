# CR-02 — Workflow désactivé et bind loopback

| Champ | Valeur |
|---|---|
| Baseline | `df50a2b242f74558d2e405f099bdfe6db6437c9c` — CR-01 qualifié localement |
| Commit CR-02 | `d993289b415ff96ed68a1fde52b50d39db63c0c4` |
| Workflow HTTP | `POST /api/workflow/run` répond `410 WORKFLOW_EXECUTION_DISABLED` avant lecture ou parsing du corps. |
| Workflow MCP | `run_workflow` est retiré du catalogue ; un appel de client historique reçoit `-32601 WORKFLOW_EXECUTION_DISABLED` avant parsing. |
| Bind | Les IP non loopback littérales, dont `0.0.0.0`, sont refusées ; le serveur est vérifié en écoute sur `127.0.0.1`. |
| Tests Go | Tests ciblés et `go test -count=1 -race ./...`, vet, build, diff-check : PASS. |
| Test réseau | Refus bind externe, socket loopback, refus workflow sans Bearer, refus workflow authentifié/origine loopback et contrôle MCP isolé : PASS. Les tokens temporaires sont supprimés. |
| Gitleaks | Re-scan `--no-git` des neuf fichiers de delta : PASS, JSON `[]`. |
| Trivy | Scans bornés `secret` et `misconfig` sur le delta : PASS. |
| OSV | Scan source : PASS ; aucun manifeste de dépendance ne change dans le diff. |
| Govulncheck | **NOT_VERIFIED_RESOURCE_TERMINATED** : le scan combiné puis le scan isolé à `GOMAXPROCS=1` ont été terminés par la sandbox. |
| Gosec | **NOT_VERIFIED_TOOL_SSA_PANIC** sur Go 1.25.13 ; journal R1 conservé. |
| SBOM | Référence : SBOM CR-01, mêmes manifestes de dépendance ; aucune régénération CR-02 après interruption de l’environnement. |
| Décision locale | `CR02_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE` |

> Les limites de Gosec et Govulncheck ne sont pas masquées : elles maintiennent `SCAN_BLOCKED_UNKNOWN`. Elles n’invalident pas les contrôles dynamiques, le scan des fichiers modifiés et l’absence démontrée de delta de dépendances.

Les journaux réseau R1 à R3 sont conservés comme diagnostic de harnais. La preuve réseau définitive est `CR02_MCP_ISOLATED_R4_RAW.log`, complétée par `CR02_NETWORK_RAW.log` pour le refus de bind externe et `CR02_NETWORK_R3_RAW.log` pour le refus workflow authentifié.
