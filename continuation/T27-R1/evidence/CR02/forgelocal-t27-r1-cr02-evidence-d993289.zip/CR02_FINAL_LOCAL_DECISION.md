# Décision locale — CR-02 Workflow/loopback

| Champ | Valeur |
|---|---|
| Décision | `CR02_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE` |
| Commit | `d993289b415ff96ed68a1fde52b50d39db63c0c4` |
| Périmètre | Désactivation fail-closed workflow HTTP/MCP et bind socket loopback IP littéral. |
| Exclusions | Aucun workflow exécuté, aucun runtime, Camoufox, proxy réel, cookie réel, SystemVault natif ou release. |
| Preuve dynamique | Refus de `0.0.0.0`, écoute `127.0.0.1`, endpoint HTTP 410 avant parsing, MCP non annoncé et appel historique refusé. |
| Qualification | `-race`, vet, build, diff-check, Gitleaks delta et Trivy secret/misconfig : PASS. |
| Réserve de scan | Gosec SSA et Govulncheck terminés par l’environnement ; OSV passe et les manifestes de dépendances sont inchangés. |

Cette décision locale ne lève aucun gate global : `PUBLIC_RELEASE_BLOCKED`, `SCAN_BLOCKED_UNKNOWN`, `NATIVE_SYSTEMVAULT_NOT_TESTED`, `camoflox_execution_authorized=false`, `t08_authorized=false` et `release_authorized=false` demeurent inchangés.
