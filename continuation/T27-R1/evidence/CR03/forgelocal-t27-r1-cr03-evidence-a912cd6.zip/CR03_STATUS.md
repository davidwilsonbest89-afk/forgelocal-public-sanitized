# CR-03 — Redaction Dashboard, cookies et MCP

| Champ | Valeur |
|---|---|
| Baseline | `d993289b415ff96ed68a1fde52b50d39db63c0c4` — CR-02 qualifié localement |
| Commit CR-03 | `a912cd6ee77ea853a1374e94a5d21932d04e0356` |
| Collecteur Dashboard | En-têtes limités à `accept`, `content-type`, `x-request-id` ; corps fetch/XHR, `authorization`, `cookie` et `set-cookie` ne sont pas capturés. |
| MCP cookies | `get_cookies` et `set_cookies` ne sont plus annoncés ; tout appel historique retourne `SENSITIVE_COOKIE_ACCESS_DISABLED` avant contexte navigateur ou parsing. |
| Sentinelles | Le test VM exécute réellement le collecteur avec token et cookie synthétiques et prouve leur absence de la télémétrie. |
| Tests | Node syntaxe, sentinelles, MCP négatif, `go test -count=1 -race ./...`, vet, build et diff-check : PASS. |
| Scans | Gitleaks delta et Trivy `secret`/`misconfig` : PASS ; aucune dépendance ne change. |
| Limites | Govulncheck et Gosec restent non qualifiés sur la lignée pour raisons d’outillage/sandbox déjà consignées ; `SCAN_BLOCKED_UNKNOWN` reste actif. |
| Décision locale | `CR03_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE` |

Les erreurs de test R1 du harnais VM sont conservées ; R2 constitue la preuve de réussite. Aucun cookie réel, navigateur, runtime, proxy réel, SystemVault natif ou release n’a été exécuté.
