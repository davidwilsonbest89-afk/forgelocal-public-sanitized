# Décision locale — CR-03

**Décision :** `CR03_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE`

Le commit `a912cd6ee77ea853a1374e94a5d21932d04e0356` rend le collecteur Dashboard fail-closed sur les valeurs sensibles et désactive les opérations MCP de lecture/écriture de cookies avant toute interaction avec un contexte navigateur. Les preuves de sentinelles sont synthétiques et ne contiennent aucune valeur opérationnelle.

Les gates restent inchangés : `PUBLIC_RELEASE_BLOCKED`, `SCAN_BLOCKED_UNKNOWN`, `NATIVE_SYSTEMVAULT_NOT_TESTED`, `camoflox_execution_authorized=false`, `t08_authorized=false` et `release_authorized=false`.
