# Décision locale — CR-04

**Décision :** `CR04_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE`

Le commit `967d29311e7d39a9bf41cbaa9f0ec3c0e48e830a` remplace le lockfile Dashboard vulnérable par une résolution pnpm intégralement auditée à zéro vulnérabilité. La qualification couvre l’installation figée sans scripts, TypeScript, build de production, test de redaction CR-03, audit final, Gitleaks, Trivy et la découverte des 22 scénarios Playwright depuis un Core loopback temporaire.

La décision ne signifie pas qu’une suite E2E complète a été rejouée. Elle confirme que la chaîne d’approvisionnement, le build et le contrat de test sont utilisables sur le lockfile remédié ; la réexécution E2E reste une obligation de qualification de release lorsque les binaires de navigateur et le harness complet seront explicitement disponibles.
