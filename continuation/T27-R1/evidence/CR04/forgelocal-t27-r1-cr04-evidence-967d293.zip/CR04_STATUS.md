# CR-04 — Chaîne d’approvisionnement Dashboard

| Champ | Valeur |
|---|---|
| Baseline | `a912cd6ee77ea853a1374e94a5d21932d04e0356` — CR-03 qualifié localement |
| Commit CR-04 | `967d29311e7d39a9bf41cbaa9f0ec3c0e48e830a` |
| Remédiation | Versions directes mises à jour, overrides pnpm transférés vers `pnpm-workspace.yaml` et lockfile entièrement régénéré. |
| Audit avant | 2 critiques, 45 hautes, 74 modérées et 9 basses pour 711 dépendances ; résultat archivé. |
| Audit final | **0 vulnérabilité** (`critical`, `high`, `moderate`, `low`) pour 697 dépendances. |
| Installation | `pnpm install --frozen-lockfile --ignore-scripts` : PASS ; `node_modules` est temporaire et exclu de toute conservation. |
| Dashboard | `pnpm check`, `pnpm build` et sentinelle CR-03 : PASS. Le warning de taille de chunk est non bloquant et le peer warning de `vite-plugin-jsx-loc` est documenté. |
| Playwright | Listing authentifié d’un Core loopback `--no-runtime` : PASS, **22 scénarios** dans 11 fichiers. Le listing ne constitue pas une réexécution E2E complète. |
| Scans | Gitleaks et Trivy `secret`/`misconfig` du delta : PASS. |
| Décision locale | `CR04_APPROVED_VERIFIABLE_LOCAL_WITH_HISTORICAL_SCAN_GATE` |

Les tests E2E complets ne sont pas rejoués dans ce lot de dépendances, car ils nécessitent un harness Dashboard complet et des binaires de navigateur non inclus dans la conservation. Leur liste et leurs préconditions sont toutefois validées depuis un Core loopback éphémère, sans runtime.

Les gates restent inchangés : `PUBLIC_RELEASE_BLOCKED`, `SCAN_BLOCKED_UNKNOWN`, `NATIVE_SYSTEMVAULT_NOT_TESTED`, `camoflox_execution_authorized=false`, `t08_authorized=false` et `release_authorized=false`.
